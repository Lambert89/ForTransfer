Repository containing the latest Android gradle plugin and its dependencies.

This gets packaged inside Studio.